const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const db = require('./db');
const { allocateSale } = require('./services/leadAllocator');
const {pushCustomerToLark} = require('./services/sync2Lark');

const app = express();
app.use(cors());
app.use(express.json());

// public uploads
app.use('/uploads', express.static('uploads'));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueName + ext);
  }
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Chỉ cho phép upload ảnh'));
    }
  }
});
app.get("/", (req, res) => {
  console.log("called");
  res.status(200).send("Server 4000 is alive!");
});
app.post('/api/customers', upload.single('qr_zalo'), async (req, res) => {
  // Dùng transaction để:
  //  1) Chọn sale theo thuật toán phân số (có lock SKIP LOCKED)
  //  2) Insert customer kèm sale_id
  const client = await db.connect();
  try {
    
    const {
      name,
      phone,
      product_interest,
      customer_source,
      note
    } = req.body;

    const qr_zalo = req.file ? req.file.filename : null;

    await client.query('BEGIN');

    // 1) Tìm sale phù hợp theo team = product_interest
    const chosen = await allocateSale({
      client,
      productInterest: product_interest,
      now: new Date()
    });

    const sale_id = chosen?.sale_id ?? null;

    // 2) Insert dữ liệu khách hàng, kèm sale_id
    const insertSql = `
      INSERT INTO customers.customer
      (name, phone, product_interest, customer_source, note, qr_zalo, sale_id)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING customer_id, sale_id, created_at
    `;

    const { rows } = await client.query(insertSql, [
      name,
      phone,
      product_interest,
      customer_source,
      note,
      qr_zalo,
      sale_id
    ]);

    await client.query('COMMIT');

    (async () => {
      try {
        await pushCustomerToLark({
          customer_id: rows[0].customer_id,
          name,
          phone,
          product_interest,
          customer_source,
          note,
          qr_zalo,
          sale_id,
          tk_lark: chosen?.tk_lark ?? null,
          created_at: rows[0].created_at,
          updated_at: null,
        });
        console.log('[LARK] Push success', rows[0].customer_id);
      } catch (err) {
        console.error(
          '[LARK] Push failed',
          err?.response?.data || err
        );
      }
    })();

    res.json({
      message: 'Lưu thành công',
      customer_id: rows?.[0]?.customer_id ?? null,
      assigned_sale_id: sale_id,
      assigned_sale_name: chosen?.sale_name ?? null,
      allocation_score: chosen?.score ?? null,
      allocation_remaining: chosen?.remaining ?? null,
      qr_url: qr_zalo
        ? `http://localhost:4000/uploads/${qr_zalo}`
        : null
    });

  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    console.error('INSERT/ALLOCATE ERROR:', err);
    res.status(500).json({ error: 'Lỗi khi lưu dữ liệu/ phân sale' });
  } finally {
    client.release();
  }
});

app.listen(4000, () => {
  console.log('Backend running on http://localhost:4000');

});
