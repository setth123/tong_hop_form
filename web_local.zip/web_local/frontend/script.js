const form = document.getElementById('customerForm');
const statusEl = document.getElementById('status');

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('qr_zalo');
const fileName = document.getElementById('fileName');
const pickFileBtn = document.getElementById('pickFileBtn');

pickFileBtn.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', () => {
  fileName.textContent = fileInput.files?.[0]?.name || 'Chưa chọn tệp';
});

// Drag highlight
['dragenter', 'dragover'].forEach(evt => {
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropzone.classList.add('dropzone--active');
  });
});

['dragleave', 'drop'].forEach(evt => {
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropzone.classList.remove('dropzone--active');
  });
});

// Submit (kết nối backend như bạn làm)
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  statusEl.textContent = 'Đang gửi dữ liệu...';

  try {
    const formData = new FormData(form);
    // unstack-cedric-nonspherically.ngrok-free.dev/backend
    const res = await fetch('https://unstack-cedric-nonspherically.ngrok-free.dev/backend/api/customers', {
      method: 'POST',
      body: formData
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data?.message || 'Gửi thất bại');

    const saleInfo = data?.assigned_sale_name
      ? `\nSale nhận lead: ${data.assigned_sale_name} (#${data.assigned_sale_id})`
      : '\nChưa phân được sale (không tìm thấy cấu hình/team phù hợp).';

    statusEl.textContent = 'Lưu thành công.' + saleInfo;
    form.reset();
    fileName.textContent = 'Chưa chọn tệp';
  } catch (err) {
    statusEl.textContent = `Lỗi: ${err.message}`;
  }
});
